"""페이지 메모리 상태를 주고받는 대화 처리. 서버 세션·집 위치 저장소는 없다."""
from copy import deepcopy
from datetime import date,datetime
import math
import re
from agent.common import load_yaml,check_schema
from agent.intent import parse,out_of_scope_action,outside_service_action,PLACES
from agent.report import emergency_check


def page_turn(text,state=None):
    if emergency_check(text):
        return {'kind':'emergency','message':load_yaml('registry/emergency_phrases.yaml')['message'],
                'state':{},'stored':False}
    if text.strip() in ('취소','초기화','대화 초기화'):
        return {'kind':'reset','message':'이 페이지의 대화와 위치 상태를 비웠습니다.','state':{},'stored':False}
    if outside_service_action(text):
        return {'kind':'unsupported','message':'시청 등 외부 기관에 대신 수리 요청하거나 접수하지 않습니다. 앱의 제보 검토와 행정기관 수리 처리는 별개입니다.','state':{},'stored':False}
    if out_of_scope_action(text):
        return {'kind':'unsupported','message':'예약·예매를 실행하지 않습니다. 보행 경로 비교·시설 제보·자료 출처 질문을 지원합니다.','state':{},'stored':False}
    intent=parse(text)
    if intent['kind']=='data_question':
        return {'kind':'delegate','text':text,'state':{},'stored':False}
    if intent['kind']=='report':
        from agent.report.preview import preview_report
        preview=preview_report(text)
        preview['questions'].append({'field':'location','message':'제보할 정확한 지점을 지도에서 확인해 주세요. 모르면 근처 표지판 등 단서를 적어 주세요.'})
        preview['needs_clarification']=True
        return {**preview,'state':{}}
    if not isinstance(state,(dict,type(None))):raise ValueError('페이지 상태 형식 확인')
    source=state or {}
    # 알 수 없는 상태·이전 대화 원문은 되돌려 주지 않는다.
    current={k:deepcopy(source[k]) for k in ('request','date','hour','minute','period','awaiting_route') if k in source}
    request=current.setdefault('request',{})
    if not isinstance(request,dict):raise ValueError('경로 상태 형식 확인')
    request={k:v for k,v in request.items() if k in ('origin','destination','preferences','departure')}
    current['request']=request
    for field in ('origin','destination'):
        if field in request:
            p=request[field]
            if not isinstance(p,dict) or not isinstance(p.get('name'),str):raise ValueError('위치 이름 확인')
            if any(isinstance(p.get(k),bool) or not isinstance(p.get(k),(int,float)) or not math.isfinite(p[k]) for k in ('lat','lng')):raise ValueError('위치 좌표 확인')
            if not(-90<=p['lat']<=90 and -180<=p['lng']<=180):raise ValueError('위치 범위 확인')
            request[field]={k:p[k] for k in ('name','lat','lng')}
    route=intent['kind']=='route' or bool(re.search(r'집으로|초등학교|대학교',text)) or current.get('awaiting_route') is True
    if not route:return {'kind':'delegate','text':text,'state':{},'stored':False}
    current['awaiting_route']=True
    # 추가 질문에 장소명만 답하면 이미 정한 출발지를 덮어쓰지 않는다.
    if source.get('awaiting_route') is True and text.strip() in PLACES:
        missing_location=next((field for field in ('destination','origin') if field not in request),None)
        if missing_location:
            lat,lng=PLACES[text.strip()]
            intent['request'].pop('origin',None);intent['request'].pop('destination',None)
            intent['request'][missing_location]={'name':text.strip(),'lat':lat,'lng':lng}
    for field in ('origin','destination'):
        if field in intent['request']:request[field]=intent['request'][field]
    request.setdefault('preferences',intent['request'].get('preferences',['none']))
    # 날짜·오전·오후를 현재 시각으로 추정하지 않는다.
    found=re.search(r'(\d{4}-\d{2}-\d{2})(?:T(\d{2}):(\d{2}))?',text)
    if found:
        date.fromisoformat(found[1]);current['date']=found[1]
        if found[2] is not None:
            h,m=int(found[2]),int(found[3])
            if not(0<=h<24 and 0<=m<60):raise ValueError('시각 범위 확인')
            current.update(hour=h,minute=m,period='24h')
    if not (found and found[2] is not None):
        found_hour=re.search(r'(?<!\d)(\d{1,2})\s*시(?:\s*(\d{1,2})\s*분)?',text)
        if found_hour:
            h,m=int(found_hour[1]),int(found_hour[2] or 0)
            if re.search(r'시\s*반',text):m=30
            if not(0<=h<24 and 0<=m<60):raise ValueError('시각 범위 확인')
            current.update(hour=h,minute=m)
            current.pop('period',None)
            if h>12 or h==0:current['period']='24h'
    if found or re.search(r'(?<!\d)\d{1,2}\s*시',text) or '오전' in text or '오후' in text:
        request.pop('departure',None)
    if '오전' in text:current['period']='am'
    elif '오후' in text:current['period']='pm'
    elif isinstance(current.get('hour'),int):
        h=current['hour']
        if ('밤' in text or '저녁' in text) and 5<=h<=11:current['period']='pm'
        elif ('새벽' in text and 1<=h<=6) or ('아침' in text and 5<=h<=11):current['period']='am'
        elif '낮' in text and h==12:current['period']='pm'
    if 'date' in current:date.fromisoformat(current['date'])
    if 'hour' in current:
        h=current['hour'];m=current.get('minute',0)
        if isinstance(h,bool) or not isinstance(h,int) or not 0<=h<24 or isinstance(m,bool) or not isinstance(m,int) or not 0<=m<60:raise ValueError('시각 상태 확인')
        if current.get('period') in ('am','pm') and not 1<=h<=12:raise ValueError('오전·오후 시각은 1~12시 확인')
    if 'departure' in request:
        datetime.fromisoformat(request['departure'])
    elif all(k in current for k in ('date','hour','period')):
        h=current['hour'];period=current['period']
        if period not in ('am','pm','24h'):raise ValueError('오전·오후 확인')
        if period=='am':h%=12
        elif period=='pm':h=h%12+12
        request['departure']=f"{current['date']}T{h:02d}:{current.get('minute',0):02d}"
    questions=[('destination','집을 포함한 도착 위치를 지도에서 선택해 주세요.'),
               ('origin','출발 위치를 지도에서 선택해 주세요.')]
    for field,message in questions:
        if field not in request:return {'kind':'clarification','missing':[field],'message':message,'state':current,'stored':False}
    if 'departure' not in request:
        if 'date' not in current:field,message='date','출발 날짜를 YYYY-MM-DD로 알려 주세요.'
        elif 'hour' not in current:field,message='hour','몇 시에 출발하나요? 오전·오후도 알려 주세요.'
        else:field,message='period','오전인가요, 오후인가요?'
        return {'kind':'clarification','missing':[field],'message':message,'state':current,'stored':False}
    check_schema('route_request',request)
    return {'kind':'route_ready','request':request,'state':current,'stored':False,
            'message':'확인된 날짜·시각과 위치로 요청을 준비했습니다. 실제 경로 계산 완료는 아닙니다.'}
