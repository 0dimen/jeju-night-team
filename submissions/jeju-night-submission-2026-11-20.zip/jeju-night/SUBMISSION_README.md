# 제주밤길 제출 묶음

서비스: https://jeju-night-team.vercel.app/app

최신 배포 소스와 서버 계산 자료를 함께 넣었습니다. 실제 키·환경·Git 이력·공개 원본은 포함하지 않습니다. `.env.example`은 값이 없는 이름 양식입니다. 원본 출처는 SUBMISSION_DATA_SOURCES.md를 확인하세요.

## 실행

Python 3.13을 기준으로 저장소 루트에서 실행합니다.

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-base.txt
.venv/bin/python -m uvicorn app:app --host 127.0.0.1 --port 8000
```

브라우저에서 http://127.0.0.1:8000/app 을 엽니다. 실제 검색·지도·보행 API는 서버 환경변수 VWORLD_API_KEY, TMAP_APP_KEY가 필요합니다. 필요하면 등록 도메인 VWORLD_DOMAIN도 설정합니다. 키를 브라우저나 Git에 넣지 않습니다. 키가 없으면 해당 외부 기능은 준비되지 않았다고 안내합니다.

runtime/facilities의 파생 계산 자료를 포함하므로 원본 없이 실행할 수 있습니다. 빌드가 필요한 경우 `python scripts/build_vercel_data.py`가 이 계산 자료를 확인합니다. `data/open` 원본 폴더는 만들 필요가 없습니다.

기술 기획서: docs/SERVICE_PLAN.md · PDF: docs/pdf/SERVICE_PLAN.pdf
현재 기능·미구현·실제 자료 범위는 이 문서를 따릅니다. 제보 영구 보관·승인·운영 점수 반영은 아직 연결되지 않았습니다. 이 ZIP 생성은 대회 접수 완료를 뜻하지 않습니다.

원본을 제외했으므로 원본 대조 시험은 건너뛸 수 있습니다. 일반 검사: `.venv/bin/python -m pytest -q --ignore=tests/browser` (검사 의존성은 requirements-test.txt).
