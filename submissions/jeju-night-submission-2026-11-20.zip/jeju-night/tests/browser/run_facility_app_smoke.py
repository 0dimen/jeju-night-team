"""설치 Chromium으로 웹앱과 실제 로컬 API 연결 검사. 외부 요청 차단."""
import json,os,socket,subprocess,sys,time
from pathlib import Path
from urllib.request import urlopen
from playwright.sync_api import sync_playwright,expect


def reveal(page,panel):
    if page.locator('#'+panel).get_attribute('open') is None:page.locator('#'+panel+' > summary').click()


def run():
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    base=f'http://127.0.0.1:{port}'
    env={k:v for k,v in os.environ.items() if k not in ('OPENAI_API_KEY','ANTHROPIC_API_KEY','GEMINI_API_KEY')}
    proc=subprocess.Popen([sys.executable,'-m','uvicorn','agent.api:app','--host','127.0.0.1','--port',str(port),'--no-access-log'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:
        for _ in range(100):
            try:
                with urlopen(base+'/health',timeout=.2):break
            except OSError:time.sleep(.1)
        else:raise RuntimeError('서버 시작 실패')
        with sync_playwright() as p:
            browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
            context=browser.new_context(viewport={'width':390,'height':844});external=[];errors=[]
            def guard(route):
                if route.request.url.startswith(base+'/'):route.continue_()
                else:external.append(route.request.url);route.abort()
            context.route('**/*',guard);page=context.new_page();page.on('pageerror',lambda error:errors.append(str(error)))
            page.goto(base+'/lab');page.wait_for_selector('.feature-grid')
            for width in (320,390,430):
                page.set_viewport_size({'width':width,'height':844})
                for screen in ('home','route','report','data','my'):
                    page.click(f'nav [data-screen={screen}]')
                    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),(width,screen)
            page.set_viewport_size({'width':390,'height':844});page.click('nav [data-screen=home]');page.screenshot(path='/tmp/jeju-nightway-home.png',full_page=True)
            page.click('.feature-grid [data-screen=route]')
            reveal(page,'research-tools');page.fill('#research-chat-input','연동 공개 구간을 CCTV 위주로 3시에 갈게요');page.click('#research-chat-send')
            expect(page.locator('#research-chat-result')).to_contain_text('날짜')
            reveal(page,'research-tools');page.fill('#research-chat-input','2026-11-20');page.click('#research-chat-send')
            expect(page.locator('#research-chat-result')).to_contain_text('오전인가요')
            reveal(page,'research-tools');page.fill('#research-chat-input','오후');page.click('#research-chat-send');page.wait_for_selector('#facility-result .route-card')
            assert '2026-11-20T15:00' in page.locator('#facility-result').inner_text()
            assert '보행 검토 0/' in page.locator('#facility-result').text_content()
            page.route('**/research/agent/conversation',lambda route:route.fulfill(status=503,body='unavailable'))
            reveal(page,'research-tools');page.fill('#research-chat-input','조명 위주로');page.click('#research-chat-send');page.wait_for_selector('#research-chat-result .error')
            assert page.input_value('#research-chat-input')=='조명 위주로'
            page.unroute('**/research/agent/conversation')
            page.click('nav [data-screen=data]');page.click('nav [data-screen=route]')
            reveal(page,'research-tools');page.fill('#research-chat-input','오후');page.click('#research-chat-send')
            expect(page.locator('#research-chat-result')).to_contain_text('공개 구간 중')
            assert page.locator('#facility-result .route-card').count()==0
            reveal(page,'research-tools');page.select_option('#facility-preference','cctv');page.click('#facility-button');page.wait_for_selector('#facility-result .route-card')
            assert page.locator('#facility-result .route-card').count()==2
            assert page.locator('#facility-result .route-card[aria-pressed=true]').get_attribute('data-route')=='FACILITY'
            assert page.locator('#facility-result svg polyline').count()==2
            page.locator('#facility-result').get_by_role('button',name='선택한 경로의 비교 근거 보기').click()
            assert page.locator('.route-progress [aria-current=step]').inner_text()=='근거 확인'
            assert page.locator('#facility-result .route-detail .metric').count()==4
            page.locator('#facility-result').get_by_role('button',name='이 경로 선택하기').click()
            assert page.locator('#facility-result .chosen-route').is_visible()
            assert page.locator('.route-progress [aria-current=step]').inner_text()=='경로 선택'
            page.locator('#facility-result').get_by_role('button',name='경로 다시 비교').click()
            assert page.locator('.route-progress [aria-current=step]').inner_text()=='경로 비교'
            page.locator('#facility-result').screenshot(path='/tmp/jeju-facility-result.png')
            page.select_option('#facility-region','seogwipo');page.click('#facility-button');page.wait_for_timeout(500)
            assert page.locator('#facility-result .route-card').count()==1
            assert '억지로 만들지 않습니다' in page.locator('#facility-result').inner_text()
            page.route('**/research/routes/facilities',lambda route:route.fulfill(status=503,body='unavailable'))
            page.click('#facility-button');page.wait_for_selector('#facility-result .error')
            assert '합성 경로로 대신하지 않았습니다' in page.locator('#facility-result').inner_text()
            assert page.input_value('#facility-region')=='seogwipo'
            page.unroute('**/research/routes/facilities')
            reveal(page,'synthetic-tools');page.select_option('#origin','제주시청');page.select_option('#destination','탑동광장');page.fill('#departure-date','2026-11-20');page.fill('#departure-time','23:00')
            page.click('#compare-button');page.wait_for_selector('#route-result .route-card')
            assert page.locator('#route-result .route-card').count()==2
            assert page.locator('#route-result .route-card[aria-pressed=true]').get_attribute('data-route')=='B'
            page.click('#route-result .route-card[data-route=A]');assert page.locator('#route-result .route-card[aria-pressed=true]').get_attribute('data-route')=='A'
            assert '경로 A' in page.locator('#route-result .route-map').get_attribute('aria-label')
            page.screenshot(path='/tmp/jeju-nightway-route.png',full_page=True)
            page.check('[name=preference][value=none]');page.click('#compare-button');page.wait_for_timeout(300)
            assert page.locator('#route-result .route-card').first.get_attribute('data-route')=='A'
            page.route('**/agent/conversation',lambda route:route.fulfill(status=503,body='unavailable'))
            page.click('#compare-button');page.wait_for_selector('#route-result .error');assert page.input_value('#origin')=='제주시청'
            page.unroute('**/agent/conversation')
            reveal(page,'synthetic-tools');page.fill('#chat-input','누가 계속 따라와요');page.click('#chat-send');page.wait_for_selector('#chat-result .error');assert '112' in page.locator('#chat-result').inner_text()
            assert page.input_value('#origin')==''
            reveal(page,'synthetic-tools');page.fill('#chat-input','CCTV 자료 출처가 뭐야?');page.click('#chat-send');page.wait_for_selector('#chat-result h2')
            assert '자료 설명' in page.locator('#chat-result').inner_text()
            page.click('nav [data-screen=report]');page.select_option('#report-location','탑동광장');page.fill('#report-text','가로등이 꺼져 있어요.');page.click('#report-preview-button');page.wait_for_selector('#report-confirm:not([hidden])')
            page.check('#report-consent');page.click('#report-submit');page.wait_for_selector('#my:not([hidden])');assert 'SYNTHETIC-RPT-' in page.locator('#receipt').inner_text() and '검토 대기' in page.locator('#receipt').inner_text()
            page.click('nav [data-screen=report]');page.select_option('#report-location','동문시장');page.fill('#report-text','CCTV와 가로등이 모두 고장 났어요');page.click('#report-preview-button');page.wait_for_timeout(300);assert page.locator('#report-confirm').is_hidden()
            page.click('nav [data-screen=route]');reveal(page,'synthetic-tools');page.select_option('#origin','동문시장');page.goto(base+'/health');page.go_back();page.wait_for_selector('#origin',state='attached');assert page.input_value('#origin')=='' and 'SYNTHETIC-RPT-' not in page.locator('#receipt').inner_text()
            page.reload();assert page.input_value('#origin')==''
            assert page.evaluate('localStorage.length+sessionStorage.length')==0
            assert not external and not errors
            browser.close()
        return {'widths':[320,390,430],'screens':5,'actual_facility_route_search':True,'reference_comparison_detail_selection_flow':True,'research_conversation_date_period_actual_route':True,'research_state_cleared_on_navigation':True,'research_failure_preserves_input':True,'same_route_no_fake_alternative':True,'missing_dataset_no_synthetic_fallback':True,'route_and_card_selection':True,'preference_changes_order':True,'failure_preserves_input':True,'emergency_clears_location':True,'preview_and_synthetic_submission':True,'ambiguous_report_not_submitted':True,'real_back_and_reload_clear':True,'external_requests':len(external),'javascript_errors':errors,'scope':'로컬 공개자료 연구 경로와 합성 대화·접수 연결. 배경지도·GPS·센터·행정기관 아님'}
    finally:proc.terminate();proc.wait(timeout=10)

if __name__=='__main__':print(json.dumps(run(),ensure_ascii=False,indent=2))
